<table>
	<tbody>
		<tr>
			<th align="center">Version</th>
			<th align="center">Notes</th>
		</tr>
		<tr>
			<td align="center">1.1.0</td>
			<td align="left">
				<ul>
					<li>Added feature that to allow changing tool hardness. See README for details.</li>
					<li>Icons used in the mod are now embedded in the dll</li>
					<li>Changed hover info on square terrain tools to use the same x,y,z convention as unity where y = height.</li>
					<li>Precision raise ground tool now displays both the change in height and the world coordinates.</li>
					<li>Sharpened image in mod icon.</li>
					<li>Updated README</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.0-1.0.2</td>
			<td align="left">
				<ul>
					<li>Initial release.</li>
					<li>Fix image links to github in README.</li>
					<li>Fix manifest description.</li>
					<li>Really wish Thunderstore let me edit typos without uploading a new version.</li>
				</ul>
			</td>
		</tr>
	</tbody>
</table>
